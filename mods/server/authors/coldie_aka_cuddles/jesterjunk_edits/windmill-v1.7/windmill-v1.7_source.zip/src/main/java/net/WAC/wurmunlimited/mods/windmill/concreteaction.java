package net.WAC.wurmunlimited.mods.windmill;

import com.wurmonline.server.FailedException;
import com.wurmonline.server.Items;
import com.wurmonline.server.MiscConstants;
import com.wurmonline.server.Server;
import com.wurmonline.server.behaviours.Action;
import com.wurmonline.server.behaviours.ActionEntry;
import com.wurmonline.server.creatures.Creature;
import com.wurmonline.server.items.Item;
import com.wurmonline.server.items.ItemFactory;
import com.wurmonline.server.items.ItemTypes;
import com.wurmonline.server.items.NoSuchTemplateException;
import com.wurmonline.server.players.Player;
import com.wurmonline.server.sounds.SoundPlayer;
import org.gotti.wurmunlimited.modloader.interfaces.WurmServerMod;
import org.gotti.wurmunlimited.modsupport.actions.ActionPerformer;
import org.gotti.wurmunlimited.modsupport.actions.BehaviourProvider;
import org.gotti.wurmunlimited.modsupport.actions.ModAction;
import org.gotti.wurmunlimited.modsupport.actions.ModActions;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class concreteaction implements WurmServerMod, ItemTypes, MiscConstants, ModAction, BehaviourProvider, ActionPerformer {
   public static short actionId;
   static ActionEntry actionEntry;

   public concreteaction() {
      actionId = (short)ModActions.getNextActionId();
      actionEntry = ActionEntry.createEntry(actionId, "Create concrete", "Creating concrete", new int[0]);
      ModActions.registerAction(actionEntry);
   }

   public BehaviourProvider getBehaviourProvider() {
      return this;
   }

   public ActionPerformer getActionPerformer() {
      return this;
   }

   public short getActionId() {
      return actionId;
   }

   public List<ActionEntry> getBehavioursFor(Creature performer, Item source, Item target) {
      return this.getBehavioursFor(performer, target);
   }

   public List<ActionEntry> getBehavioursFor(Creature performer, Item target) {
      return performer instanceof Player && target.getTemplateId() == windmill.windmilltemplateid ? Arrays.asList(actionEntry) : null;
   }

   public boolean action(Action act, Creature performer, Item source, Item target, short action, float counter) {
      return this.action(act, performer, target, action, counter);
   }

   public boolean action(Action act, Creature performer, Item target, short action, float counter) {
      String actionstring = act.getActionEntry().getActionString().toLowerCase();
      int actiontime = 1800;
      int tickTimes = windmill.windmillinitialtime;
      int absolutewindpower = (int)(10.0F * Math.abs(Server.getWeather().getWindPower()));
      if (!windmill.usewind) {
         absolutewindpower = 0;
      }

      tickTimes -= absolutewindpower;
      if (target.getTemplateId() == windmill.windmilltemplateid) {
         if (counter == 1.0F) {
            performer.sendActionControl(actionstring, true, actiontime);
            performer.getCommunicator().sendNormalServerMessage("You start to create concrete.");
         }

         if (act.currentSecond() % tickTimes == 0) {
            if (performer.getStatus().getStamina() < 5000) {
               performer.getCommunicator().sendNormalServerMessage("You must rest.");
               return true;
            }

            performer.getStatus().modifyStamina(-2000.0F);
            Item[] currentItems = target.getAllItems(true);
            int clayTally = 0;
            int rockShardTally = 0;
            int produceTally = 0;

            // Count how many clay and rock shards are present
            for (Item i : currentItems) {
               if (i.getTemplateId() == 130 && i.getWeightGrams() >= 1000) { // Clay
                  ++clayTally;
               } else if (i.getTemplateId() == 146 && i.getWeightGrams() >= 2000) { // Rock Shard
                  ++rockShardTally;
               } else if (i.getTemplateId() == 782) { // Concrete
                  ++produceTally;
               }
            }

            // Stop if too much concrete is produced
            if (produceTally >= 1000) {
               return true;
            }

            //
            //  item id reference
            //
            //   28 barley
            //   29 wheat
            //   30 rye
            //   31 oat
            //   32 corn
            //  146 rock shard
            //  130 clay
            //  201 flour
            //  782 concrete
            // 1220 cornflour
            //

            // Create concrete if both clay and rock shards are available
            int countcreated = 0;
            int concretecount = 0;
            String concretecreatedname = "";

            // Use the minimum of available clay and rock shards
            int consumeTally = Math.min(clayTally, rockShardTally);

            if (consumeTally != 0) {
               boolean playsound = false;

               // Separate item lists to handle both clay and rock shards properly
               List<Item> clayItems = Arrays.stream(currentItems)
                        .filter(i -> i.getTemplateId() == 130 && i.getWeightGrams() >= 1000)
                        .collect(Collectors.toList());

               List<Item> rockShardItems = Arrays.stream(currentItems)
                        .filter(i -> i.getTemplateId() == 146 && i.getWeightGrams() >= 2000)
                        .collect(Collectors.toList());

               for (int i = 0; i < consumeTally; i++) {
                  Item clayItem = clayItems.get(i);
                  Item rockShardItem = rockShardItems.get(i);

                  try {
                     // Consume clay
                     byte material = clayItem.getMaterial();
                     Item toInsert = ItemFactory.createItem(782, clayItem.getQualityLevel(), material, clayItem.getRarity(), null);

                     if (clayItem.getRarity() != 0) {
                        clayItem.setRarity((byte) 0);
                     }

                     playsound = true;
                     target.insertItem(toInsert, true);
                     ++concretecount;
                     concretecreatedname = toInsert.getName();

                     // Reduce clay weight
                     clayItem.setWeight(clayItem.getWeightGrams() - 1000, false);
                     if (clayItem.getWeightGrams() < 1000) {
                        Items.destroyItem(clayItem.getWurmId());
                     }

                     // Reduce rock shard weight
                     rockShardItem.setWeight(rockShardItem.getWeightGrams() - 2000, false);
                     if (rockShardItem.getWeightGrams() < 2000) {
                        Items.destroyItem(rockShardItem.getWurmId());
                     }
                  } catch (NoSuchTemplateException | FailedException e) {
                     e.printStackTrace();
                  }
               }

               // Send success message
               if (playsound) {
                  performer.getCommunicator().sendSafeServerMessage("Created " + concretecount + " " + concretecreatedname);
                  SoundPlayer.playSound("sound.grindstone", target, 0.0F);
                  return false;
               }
            }

            return true;
         }
      }

      return false;
   }
}
