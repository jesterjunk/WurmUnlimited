rem build_windmill.bat

@echo off


rem Define path variables
set         "VERSION=v1.7"
set      "JAVAC_PATH=C:\Program Files\Java\jdk1.8.0_05\bin\javac.exe"
set      "SERVER_JAR=F:\Games\SteamLibrary\steamapps\common\Wurm Unlimited Dedicated Server - Modded\server.jar"
set      "COMMON_JAR=F:\Games\SteamLibrary\steamapps\common\Wurm Unlimited Dedicated Server - Modded\common.jar"
set "MODLAUNCHER_JAR=F:\Games\SteamLibrary\steamapps\common\Wurm Unlimited Dedicated Server - Modded\modlauncher.jar"
set        "JAR_PATH=C:\Program Files\Java\jdk1.8.0_05\bin\jar.exe"


rem Step 1: Remove bin directory and all of its files
if exist bin (rmdir /S /Q bin)


rem Step 2: Create empty /bin directory
mkdir bin


rem Step 3: Compile Java source files with specified classpath
"%JAVAC_PATH%" -source 1.8 -target 1.8 -classpath "%SERVER_JAR%;%COMMON_JAR%;%MODLAUNCHER_JAR%" -d bin src\main\java\net\WAC\wurmunlimited\mods\windmill\*.java


rem Step 4: Remove mods\Windmill directory and all of its files
if exist mods\Windmill (rmdir /S /Q mods\Windmill)


rem Step 5: Create empty mods\Windmill directory
mkdir mods\Windmill


rem Step 6: Package compiled classes into a JAR file
"%JAR_PATH%" cvf mods\Windmill\Windmill.jar -C bin\ .


rem Step 7: Package assets into a JAR file
"%JAR_PATH%" cvf mods\Windmill\windmill-pack.jar -C pack\ .


rem Step 8: Remove /dist directory and all of its files
if exist dist (rmdir /S /Q dist)


rem Step 9: Zip with maximum compression the mods directory and save it to dist directory
mkdir dist
tar -a -c -f dist\windmill-%VERSION%.zip mods


rem Step 10: Generate SHA-256 hash file for windmill.zip
for /f "tokens=1" %%i in ('certutil -hashfile dist\windmill-%VERSION%.zip SHA256 ^| findstr /v "CertUtil"') do echo %%i *windmill-%VERSION%.zip > dist\windmill-%VERSION%.zip.sha256
